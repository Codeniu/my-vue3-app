<template>
  <div style="width: 600px">
    <div class="name">
      {{ currentAudioName || audioList[0]?.title }}
    </div>
    <AudioPlayer
      ref="audioPlayer"
      :audio-list="audioList"
      :before-play="handleBeforePlay"
      :show-play-loading="true"
      themeColor="#10a0e9"
      @ended="handleEnded"
      @play-error="
        (error) => {
          console.error('播放错误:', error)
        }
      "
    >
    </AudioPlayer>

    <TlAudioPlayer
      ref="audioPlayer"
      :audio-list="audioList"
      :before-play="handleBeforePlay"
      :show-play-loading="true"
      themeColor="#10a0e9"
      @ended="handleEnded"
      @play-error="
        (error) => {
          console.error('播放错误:', error)
        }
      "
    >
      <template #title>
        <div class="custom-title">
          {{ currentAudioName || audioList[0]?.title }}
        </div>
      </template>
    </TlAudioPlayer>

    <button @click="handlePlaySpecify">Play the second audio</button>
  </div>
</template>

<script setup>
import { ref, nextTick, onMounted } from 'vue'
import AudioPlayer from '../components/vue3-audio-player/index.vue'
import TlAudioPlayer from '../components/vue3-audio-player/TlAudioPlayer.vue'

const audioPlayer = ref(null)
const currentAudioName = ref('')
// 添加 onMounted 钩子
onMounted(() => {
  console.log('组件已挂载:', audioPlayer.value)
})

const audioList = [
  {
    src: 'http://music.163.com/song/media/outer/url?id=317151.mp3',
    title: 'Audio Title 1',
    artist: 'Artist Name 1',
    album: 'Album Name 1',
    artwork: [
      {
        src: 'https://upload.jianshu.io/users/upload_avatars/1696356/c358e43854eb?imageMogr2/auto-orient/strip|imageView2/1/w/96/h/96/format/webp',
        sizes: '512x512',
        type: 'image/jpg',
      },
    ],
  },
  {
    src: 'http://downsc.chinaz.net/Files/DownLoad/sound1/201906/11582.mp3',
    title: 'Audio Title 2',
  },
]

const handleBeforePlay = (next) => {
  currentAudioName.value = audioList[audioPlayer.value.currentPlayIndex]?.title
  next()
}

const handlePlaySpecify = () => {
  audioPlayer.value.currentPlayIndex = 1
  nextTick(() => {
    audioPlayer.value.play()
    currentAudioName.value = audioList[audioPlayer.value.currentPlayIndex]?.title
  })
}

const handleEnded = () => {
  console.log('ended')
}
</script>

<style scoped>
.name {
  text-align: center;
  line-height: 80px;
}
</style>
